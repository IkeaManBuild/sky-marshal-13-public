# sky-marshal-13

Sky Marshal 13 is a new server inspired from a long expired ROBLOX game named Sky Marshals. In a teamwork based game, passengers, pilots and the Sky Marshal has to prevent suspicious individuals (the Pirates) from hijacking the aircraft. The Pirates must work together to hijack the aircraft, restrain or kill the pilots and fly to an off-course destination, while the pilots must maintain their course. Like every other plane, if it's not controlled, it'll crash. We have more ideas and stuff to come, and everything is subject to change.
